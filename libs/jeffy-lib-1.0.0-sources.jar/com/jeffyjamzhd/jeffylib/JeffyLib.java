package com.jeffyjamzhd.jeffylib;

import net.fabricmc.api.ModInitializer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class JeffyLib implements ModInitializer {
    public static final String MOD_ID = "jeffy-lib";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("The little Jeffies are working tirelessly...");
    }
}
