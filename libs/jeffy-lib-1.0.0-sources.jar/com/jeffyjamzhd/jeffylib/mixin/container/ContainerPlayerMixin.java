package com.jeffyjamzhd.jeffylib.mixin.container;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.ContainerPlayer;
import net.minecraft.Item;
import net.minecraft.ItemArmor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(ContainerPlayer.class)
public class ContainerPlayerMixin {
    @ModifyExpressionValue(method = "transferStackInSlot", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/ItemStack;getItem()Lnet/minecraft/Item;",
            ordinal = 0))
    private Item checkArmor(Item original) {
        if (original instanceof ItemArmor armor && !armor.jl$canBeWorn()) {
            return null;
        }
        return original;
    }
}
