package com.jeffyjamzhd.jeffylib.mixin.slot;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.ItemArmor;
import net.minecraft.ItemStack;
import net.minecraft.SlotArmor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(SlotArmor.class)
public class SlotArmorMixin {
    @ModifyReturnValue(method = "isItemValid", at = @At("RETURN"))
    private boolean verifyItemValidity(boolean original,
                                       @Local(ordinal = 0, argsOnly = true) ItemStack stack) {
        if (stack.getItem() instanceof ItemArmor armor) {
            return armor.jl$canBeWorn() && original;
        }
        return original;
    }
}
